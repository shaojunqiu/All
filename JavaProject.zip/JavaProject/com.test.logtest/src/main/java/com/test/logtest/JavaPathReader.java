package com.test.logtest;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.net.URLDecoder;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.config.ConfigurationSource;
import org.apache.logging.log4j.core.config.Configurator;

public class JavaPathReader {
	
	public static void main(String[] args) {
		try {
			//String path = getPath();
			//String test = System.getProperties().getProperty("user.dir");
			String log4JPropertyFile = new JavaPathReader().getClass().getProtectionDomain().getCodeSource().getLocation().getPath();
			int endIdx = log4JPropertyFile.lastIndexOf("/");
			log4JPropertyFile = log4JPropertyFile.substring(0, endIdx);
			endIdx = log4JPropertyFile.lastIndexOf("/");
			log4JPropertyFile = log4JPropertyFile.substring(0, endIdx+1);
			log4JPropertyFile = URLDecoder.decode(log4JPropertyFile, "UTF-8");
			System.setProperty("LOG_PATH", log4JPropertyFile);
			FileInputStream br = new FileInputStream(log4JPropertyFile + "conf/log4j2.xml");
			ConfigurationSource cs = new ConfigurationSource(br);
			Configurator.initialize(null, cs);
			Logger logger = LogManager.getLogger(JavaPathReader.class);
		    int loop = 5000;
		    while(loop != 0)
		    {
		    	loop--;
		        logger.info("Wow! I'm configured!");
		    }
			//int miao = 3;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static String getPath() {
		try {
			return JavaPathReader.class.getProtectionDomain().getCodeSource().getLocation().getPath();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}
	}
}
